package world.dailydeal.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.Locale;
import java.util.UUID;

/**
 * Daily Deal — রিসেলার অ্যাপ।
 * সাইটের রিসেলিং অংশটাই WebView-তে অ্যাপ আকারে চলে (সাইট আপডেট করলে অ্যাপ নিজে থেকেই আপডেট হয়)।
 */
public class MainActivity extends Activity {

    // ===== কনফিগ (দরকার হলে শুধু এখানে বদলান) =====
    static final String SITE_URL = "https://dailydeal.world/";
    static final String START_URL = SITE_URL + "?app=1";
    static final String[] ALLOWED_HOSTS = {
            "dailydeal.world", "firebaseapp.com", "gstatic.com", "recaptcha.net", "google.com"
    };
    static final String STATUS_DEFAULT = "#0F0D0A";
    static final String SPLASH_BG = "#000000";
    static final String ACCENT = "#F4601E";

    private static final int REQ_FILE = 1001;
    private static final int REQ_LOC = 1002;

    private WebView web;
    private FrameLayout root;
    private View splash;
    private View errorLayer;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    private ValueCallback<Uri[]> filePathCallback;
    private GeolocationPermissions.Callback geoCb;
    private String geoOrigin;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pageReady = false;
    private boolean pageFinishedOnce = false;
    private boolean pageError = false;
    private boolean backPending = false;
    private int backToken = 0;
    private long lastBack = 0;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStatusBar(STATUS_DEFAULT);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor(SPLASH_BG));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor(SPLASH_BG));
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        splash = buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));

        errorLayer = buildErrorLayer();
        errorLayer.setVisibility(View.GONE);
        root.addView(errorLayer, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setGeolocationEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " DailyDealApp/" + versionCode());

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "DDApp");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                startDownload(url, ua, cd, mime);
            }
        });

        if (savedInstanceState == null || web.restoreState(savedInstanceState) == null) {
            web.loadUrl(START_URL);
        }

        // সর্বোচ্চ ১২ সেকেন্ড পর স্প্ল্যাশ সরিয়ে দেওয়া (নেটওয়ার্ক ধীর হলেও আটকে থাকবে না)
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideSplash();
            }
        }, 12000);
    }

    // ===================== UI বিল্ডার =====================

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private View buildSplash() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.parseColor(SPLASH_BG));
        box.setClickable(true);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.splash_logo);
        logo.setAdjustViewBounds(true);
        box.addView(logo, new LinearLayout.LayoutParams(dp(220), dp(220)));
        logo.setAlpha(0f);
        logo.setScaleX(0.86f);
        logo.setScaleY(0.86f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520).start();

        TextView name = new TextView(this);
        android.text.SpannableString nm = new android.text.SpannableString("DAILY DEAL");
        nm.setSpan(new android.text.style.ForegroundColorSpan(Color.WHITE), 0, 5, 0);
        nm.setSpan(new android.text.style.ForegroundColorSpan(Color.parseColor(ACCENT)), 6, 10, 0);
        name.setText(nm);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setLetterSpacing(0.04f);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-2, -2);
        np.topMargin = dp(0);
        box.addView(name, np);

        TextView sub = new TextView(this);
        sub.setText("রিসেলার অ্যাপ");
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        sub.setTextColor(Color.parseColor("#9A9A9A"));
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.topMargin = dp(4);
        box.addView(sub, sp);

        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(26), dp(26));
        pp.topMargin = dp(28);
        box.addView(pb, pp);
        return box;
    }

    private View buildErrorLayer() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Color.parseColor(SPLASH_BG));
        box.setPadding(dp(32), dp(32), dp(32), dp(32));
        box.setClickable(true);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.splash_logo);
        logo.setAlpha(0.8f);
        box.addView(logo, new LinearLayout.LayoutParams(dp(90), dp(90)));

        TextView t = new TextView(this);
        t.setText("ইন্টারনেট সংযোগ নেই");
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.topMargin = dp(18);
        box.addView(t, tp);

        TextView m = new TextView(this);
        m.setText("অনুগ্রহ করে মোবাইল ডেটা বা Wi-Fi চালু করে আবার চেষ্টা করুন।");
        m.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        m.setTextColor(Color.parseColor("#B5B5B5"));
        m.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-2, -2);
        mp.topMargin = dp(8);
        box.addView(m, mp);

        Button b = new Button(this);
        b.setText("আবার চেষ্টা করুন");
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackgroundColor(Color.parseColor(ACCENT));
        b.setPadding(dp(28), dp(10), dp(28), dp(10));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
        bp.topMargin = dp(24);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retry();
            }
        });
        box.addView(b, bp);
        return box;
    }

    private void retry() {
        pageError = false;
        errorLayer.setVisibility(View.GONE);
        splash.setVisibility(View.VISIBLE);
        splash.setAlpha(1f);
        pageReady = false;
        web.loadUrl(START_URL);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideSplash();
            }
        }, 12000);
    }

    private void hideSplash() {
        if (splash == null || splash.getVisibility() != View.VISIBLE) return;
        splash.animate().alpha(0f).setDuration(280).withEndAction(new Runnable() {
            @Override
            public void run() {
                splash.setVisibility(View.GONE);
            }
        }).start();
    }

    private void setStatusBar(String color) {
        try {
            Window w = getWindow();
            int c = Color.parseColor(color);
            w.setStatusBarColor(c);
            w.setNavigationBarColor(Color.parseColor("#000000"));
            if (Build.VERSION.SDK_INT >= 23) {
                View d = w.getDecorView();
                int flags = d.getSystemUiVisibility();
                double lum = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
                if (lum > 0.6) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                d.setSystemUiVisibility(flags);
            }
        } catch (Throwable ignored) {
        }
    }

    private int versionCode() {
        try {
            return (int) getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable e) {
            return 0;
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable e) {
            return "";
        }
    }

    // ===================== ব্যাক বাটন =====================

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (errorLayer.getVisibility() == View.VISIBLE || !pageFinishedOnce) {
            rootBack();
            return;
        }
        backPending = true;
        final int tok = ++backToken;
        web.evaluateJavascript(
                "(function(){try{if(window.__ddBack){window.__ddBack();return 1}}catch(e){}return 0})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String v) {
                        if ("0".equals(v) && backToken == tok && backPending) {
                            backPending = false;
                            rootBack();
                        }
                    }
                });
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (backPending && backToken == tok) {
                    backPending = false;
                    rootBack();
                }
            }
        }, 900);
    }

    private void rootBack() {
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) {
            finish();
        } else {
            lastBack = now;
            Toast.makeText(this, "বের হতে আবার ব্যাক চাপুন", Toast.LENGTH_SHORT).show();
        }
    }

    // ===================== WebViewClient =====================

    private boolean hostAllowed(String host) {
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        for (String h : ALLOWED_HOSTS) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private boolean openExternal(String url) {
        try {
            Intent i;
            if (url.startsWith("intent:")) {
                i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
            } else {
                i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return true;
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "এই লিংক খোলার মতো অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
            return true;
        } catch (Throwable e) {
            return true;
        }
    }

    private class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
            if (scheme.equals("http") || scheme.equals("https")) {
                if (!req.isForMainFrame()) return false;
                if (hostAllowed(u.getHost())) return false;
                return openExternal(u.toString());
            }
            if (scheme.equals("about") || scheme.equals("blob") || scheme.equals("data") || scheme.equals("javascript")) {
                return false;
            }
            return openExternal(u.toString());
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            pageError = false;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            pageFinishedOnce = true;
            if (!pageError) {
                errorLayer.setVisibility(View.GONE);
                // সাইট নিজে pageReady() না ডাকলেও ৩ সেকেন্ড পর স্প্ল্যাশ সরবে
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        hideSplash();
                    }
                }, 3000);
            }
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
            if (req.isForMainFrame()) {
                pageError = true;
                pageFinishedOnce = true;
                errorLayer.setVisibility(View.VISIBLE);
                splash.setVisibility(View.GONE);
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
            recreate();
            return true;
        }
    }

    // ===================== WebChromeClient =====================

    private class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = cb;
            try {
                startActivityForResult(params.createIntent(), REQ_FILE);
            } catch (Throwable e) {
                filePathCallback = null;
                Toast.makeText(MainActivity.this, "ফাইল বাছাই করা যাচ্ছে না", Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            boolean ok = Build.VERSION.SDK_INT < 23
                    || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            if (ok) {
                cb.invoke(origin, true, false);
            } else {
                geoCb = cb;
                geoOrigin = origin;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            }
        }

        @Override
        public boolean onJsAlert(WebView v, String url, String message, final JsResult r) {
            new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("ঠিক আছে", new android.content.DialogInterface.OnClickListener() {
                        public void onClick(android.content.DialogInterface d, int w) {
                            r.confirm();
                        }
                    }).setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {
                        public void onCancel(android.content.DialogInterface d) {
                            r.cancel();
                        }
                    }).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String message, final JsResult r) {
            new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("হ্যাঁ", new android.content.DialogInterface.OnClickListener() {
                        public void onClick(android.content.DialogInterface d, int w) {
                            r.confirm();
                        }
                    }).setNegativeButton("না", new android.content.DialogInterface.OnClickListener() {
                        public void onClick(android.content.DialogInterface d, int w) {
                            r.cancel();
                        }
                    }).setOnCancelListener(new android.content.DialogInterface.OnCancelListener() {
                        public void onCancel(android.content.DialogInterface d) {
                            r.cancel();
                        }
                    }).show();
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            root.addView(view, new FrameLayout.LayoutParams(-1, -1));
            web.setVisibility(View.GONE);
        }

        @Override
        public void onHideCustomView() {
            hideCustomView();
        }
    }

    private void hideCustomView() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        web.setVisibility(View.VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    // ===================== ডাউনলোড =====================

    private void startDownload(String url, String ua, String cd, String mime) {
        try {
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                Toast.makeText(this, "এই ফাইলটি অ্যাপ থেকে ডাউনলোড করা যাচ্ছে না", Toast.LENGTH_SHORT).show();
                return;
            }
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            String name = URLUtil.guessFileName(url, cd, mime);
            r.setMimeType(mime);
            r.addRequestHeader("User-Agent", ua);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) r.addRequestHeader("Cookie", ck);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            Toast.makeText(this, "ডাউনলোড শুরু হয়েছে", Toast.LENGTH_SHORT).show();
        } catch (Throwable e) {
            openExternal(url);
        }
    }

    // ===================== অ্যাক্টিভিটি রেজাল্ট / পারমিশন =====================

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            if (filePathCallback != null) {
                Uri[] r = null;
                try {
                    r = WebChromeClient.FileChooserParams.parseResult(res, data);
                } catch (Throwable ignored) {
                }
                filePathCallback.onReceiveValue(r);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        if (req == REQ_LOC && geoCb != null) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            geoCb.invoke(geoOrigin, ok, false);
            geoCb = null;
            geoOrigin = null;
        }
        super.onRequestPermissionsResult(req, perms, results);
    }

    // ===================== লাইফসাইকেল =====================

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        try {
            web.saveState(out);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try {
            root.removeView(web);
            web.destroy();
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    // ===================== সাইট ↔ অ্যাপ ব্রিজ (window.DDApp) =====================

    private class Bridge {
        @JavascriptInterface
        public int getVersionCode() {
            return versionCode();
        }

        @JavascriptInterface
        public String getVersionName() {
            return versionName();
        }

        /** এই ফোনের স্থায়ী র‍্যান্ডম আইডি (অ্যাপ আনইনস্টল করলে নতুন হবে) */
        @JavascriptInterface
        public String getDeviceId() {
            SharedPreferences p = getSharedPreferences("dd_app", MODE_PRIVATE);
            String id = p.getString("device_id", null);
            if (id == null) {
                id = "a" + UUID.randomUUID().toString().replace("-", "").substring(0, 24);
                p.edit().putString("device_id", id).apply();
            }
            return id;
        }

        /** ফোনের স্থায়ী আইডি (ANDROID_ID-র হ্যাশ) — অ্যাপ আনইনস্টল/রিইনস্টল করলেও একই থাকে; এক ডিভাইসে একটি অ্যাকাউন্টের নিয়মে ব্যবহার হয় */
        @JavascriptInterface
        public String getHardwareId() {
            try {
                String aid = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
                if (aid == null || aid.length() < 8 || aid.equals("9774d56d682e549c")) return getDeviceId();
                java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
                byte[] d = md.digest(("dailydeal|" + aid).getBytes("UTF-8"));
                StringBuilder sb = new StringBuilder("h");
                for (int i = 0; i < 16; i++) sb.append(String.format(java.util.Locale.ROOT, "%02x", d[i]));
                return sb.toString();
            } catch (Throwable e) {
                return getDeviceId();
            }
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            try {
                JSONObject o = new JSONObject();
                o.put("model", (Build.MANUFACTURER + " " + Build.MODEL).trim());
                o.put("android", Build.VERSION.RELEASE);
                o.put("sdk", Build.VERSION.SDK_INT);
                return o.toString();
            } catch (Throwable e) {
                return "{}";
            }
        }

        /** আপডেট APK ইত্যাদি লিংক ব্রাউজারে খুলবে (সেখান থেকে ডাউনলোড হবে) */
        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openExternal(url);
                }
            });
        }

        @JavascriptInterface
        public void share(final String title, final String text, final String url) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        StringBuilder sb = new StringBuilder();
                        if (text != null && text.length() > 0) sb.append(text);
                        if (url != null && url.length() > 0) {
                            if (sb.length() > 0) sb.append("\n");
                            sb.append(url);
                        }
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        if (title != null) i.putExtra(Intent.EXTRA_SUBJECT, title);
                        i.putExtra(Intent.EXTRA_TEXT, sb.toString());
                        startActivity(Intent.createChooser(i, "শেয়ার করুন"));
                    } catch (Throwable ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void setStatusBar(final String color) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    MainActivity.this.setStatusBar(color);
                }
            });
        }

        @JavascriptInterface
        public void pageReady() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pageReady = true;
                    hideSplash();
                }
            });
        }

        @JavascriptInterface
        public void backDone(final boolean handled) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!backPending) return;
                    backPending = false;
                    if (!handled) rootBack();
                }
            });
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            });
        }
    }
}
